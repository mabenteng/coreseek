<?php

$s=$_GET['s'];

switch($s){
	case 'checkscwsword':
		checkscwsword();
	break;
	case 'checkmmword':
		checkmmword();
	break;
	case 'uniqueword':
		uniqueword();
	break;
	case 'setword':
		setword();
	break;
}

function checkscwsword(){
	@unlink('dictutf8_check.txt');
	$handle= fopen('dictutf8.txt','r');
	$w = fopen('dictutf8_check.txt','a+');
	if ($handle && $w) {
		while (($buffer = fgets($handle, 4096)) !== false) {
			$line = preg_split("/[\r\n\t ]/",$buffer);
			
			fwrite($w,"$line[0]\r\n");
		
		}
		if (!feof($handle)) {
			echo "Error: unexpected fgets() fail\n";
		}
		fclose($handle);
		fclose($w);
	}
}

function checkmmword(){
	@unlink('unigram_check.txt');
	$handle= fopen('unigram.txt','r');
	$w = fopen('unigram_check.txt','a+');
	if ($handle && $w) {
		while (($buffer = fgets($handle, 4096)) !== false) {
			if(strstr($buffer,'x:')) continue;
			$line = preg_split("/[\r\n\t ]/",$buffer);
			fwrite($w,"$line[0]\r\n");
		}
		if (!feof($handle)) {
			echo "Error: unexpected fgets() fail\n";
		}
		fclose($handle);
		fclose($w);
	}
}


function uniqueword(){
	set_time_limit(0);
	$handle= fopen('dictutf8_check.txt','r');
	$arrStr=array();
	$i=0;
	if ($handle) {
		while (($buffer = fgets($handle, 50)) !== false) {
			$line = trim($buffer,"\r\n\t ");
			$arr[]=$line;
		}
		if (!feof($handle)) {
			echo "Error: unexpected fgets() fail\n";
		}
		fclose($handle);
	}
	$handle= fopen('unigram_check.txt','r');
	if ($handle) {
		while (($buffer = fgets($handle, 50)) !== false) {
			$line = trim($buffer,"\r\n\t ");
			//if(strstr($arrStr.',',','.$line.',')) continue;
			$arr[]=$line;
		}
		if (!feof($handle)) {
			echo "Error: unexpected fgets() fail\n";
		}
		fclose($handle);
	}
	$arr=array_unique($arr);
	@unlink('word_unique.txt');
	$w = fopen('word_unique.txt','a+');
	fwrite($w,implode("\r\n",$arr));
	fclose($w);
	exit('success');
}

function setword(){
	@unlink('success.txt');
	$handle= fopen('word_unique.txt','r');
	$w = fopen('success.txt','a+');
	if ($handle && $w) {
		while (($buffer = fgets($handle, 4096)) !== false) {
			$line = trim($buffer,"\r\n\t ");
			fwrite($w,"$line\t1\r\nx:1\r\n");
		
		}
		if (!feof($handle)) {
			echo "Error: unexpected fgets() fail\n";
		}
		fclose($handle);
		fclose($w);
	}
}
?>